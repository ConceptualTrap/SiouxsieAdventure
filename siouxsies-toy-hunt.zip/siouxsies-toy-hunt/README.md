# Siouxsie's Toy Hunt

A painterly autumn side-scroller starring Siouxsie, a scruffy terrier who has caught the scent of her favorite stuffed toy.

Hop the logs, leap the creeks, chase squirrels up their trees, bark the geese off the path, sniff out buried bones, and claim the prize (which does not survive).

## Play

The whole game is one file, `index.html`, with no build step and no dependencies. Open it in a browser, or publish it with GitHub Pages:

1. Push this folder to a GitHub repository.
2. In the repository, go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, and save.
4. After a minute the game is live at `https://<your-username>.github.io/<repo-name>/`.

## Controls

| Action | Keyboard | Phone (landscape) |
| --- | --- | --- |
| Walk / turn around | ← → or A D | ◀ ▶ |
| Run | Keep holding a direction | Keep holding ◀ ▶ |
| Jump (hold for higher) | Space, ↑ or W | Jump |
| Sniff and dig up bones | ↓ or S | Sniff |
| Bark (shoos geese) | R | Bark |

On phones, hold the device sideways. A Full screen button appears where the browser supports it.

## How it's made

Everything is drawn in code on an HTML canvas. The scenery is painted once at load from thousands of small brush dabs, then layered with parallax and a canvas-weave paper texture. Siouxsie is a procedural rig: two-bone leg IK with walk and gallop cycles, spring-driven ears and body, a physics-chained feathery tail, and blended poses for sniffing, digging, sitting, shaking off water, barking and dancing.

Fonts load from Google Fonts (Young Serif, Karla, Caveat); the game falls back to system fonts offline.
